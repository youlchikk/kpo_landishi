CREATE TABLE audit_cards (
recId INT IDENTITY(1,1) PRIMARY KEY, 
recdate DATETIME, 
CardNumber_old varchar(12),
CardNumber_new varchar(12) NULL,
CardTypeCode_old int      ,
CardTypeCode_new int  NULL    ,
Validity_old datetime	   ,
Validity_new datetime NULL);


GO
CREATE TRIGGER modifyy ON Cards AFTER UPDATE, DELETE
AS
BEGIN
DECLARE
@CardNumber_old varchar(12),
@CardNumber_new varchar(12),
@CardTypeCode_old int      ,
@CardTypeCode_new int      ,
@Validity_old datetime	   ,
@Validity_new datetime

SET @CardNumber_old  = (SELECT CardNumber FROM deleted)
SET @CardNumber_new  = (SELECT CardNumber FROM inserted) 
SET @CardTypeCode_old = (SELECT CardTypeCode FROM deleted) 
SET @CardTypeCode_new = (SELECT CardTypeCode FROM inserted) 
SET @Validity_old= (SELECT Validity FROM deleted) 
SET @Validity_new = (SELECT Validity FROM inserted) 



 INSERT INTO audit_cards (recdate, CardNumber_old, CardNumber_new, CardTypeCode_old, CardTypeCode_new, Validity_old, Validity_new) VALUES
(GETDATE(), @CardNumber_old, @CardNumber_new, @CardTypeCode_old, @CardTypeCode_new, @Validity_old, @Validity_new)
END




GO
CREATE TRIGGER empl_integrity ON Cards AFTER INSERT, UPDATE 
AS
BEGIN
IF (SELECT Customers.CustomerID FROM Customers, inserted
WHERE Customers.CustomerID = inserted.CustomerID) IS NULL
BEGIN
ROLLBACK TRANSACTION
PRINT '������ �� ���������/�� ��������'
END
ELSE PRINT '������ ���������/��������'	
END

GO
CREATE TRIGGER PreventTriggerDeletion
ON Cards
INSTEAD OF DELETE
AS
BEGIN
    RAISERROR('Deleting triggers is not allowed.', 16, 1);
    ROLLBACK TRANSACTION;
END

DROP TRIGGER Cards.PreventTriggerDeletion;  

