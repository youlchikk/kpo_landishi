-- SELECT * FROM Journal

-- SELECT * FROM Cards
-- WHERE Validity < GETDATE();

-- SELECT * FROM Cards
-- WHERE Validity < '12-12-2024' 
-- AND Validity > GETDATE() 
-- AND CardTypeCode = '2';

-- SELECT * FROM Journal
-- WHERE Total = 5000 OR Total = 12000
-- OR Total = 15000 OR Total = 20000;

-- DECLARE @startOfCurrentMonth DATETIME
-- SET @startOfCurrentMonth = DATEADD(month, DATEDIFF(month, 0, CURRENT_TIMESTAMP), 0)
-- SELECT * FROM Journal
-- WHERE Datee >= DATEADD(month, -1, @startOfCurrentMonth) 
-- AND Datee < @startOfCurrentMonth;

-- USE CreditCards;
-- SELECT * FROM Customers
-- WHERE Phone IS NULL;

-- SELECT * FROM Customers
-- WHERE LName LIKE '��%'

